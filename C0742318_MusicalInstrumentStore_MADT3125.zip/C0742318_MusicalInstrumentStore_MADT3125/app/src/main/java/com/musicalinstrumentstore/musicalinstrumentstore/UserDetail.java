package com.musicalinstrumentstore.musicalinstrumentstore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class UserDetail extends AppCompatActivity {
    private TextView txtcId, txtcName, txtcEmail, txtcAddress, txtcCity, txtcState,txtcPincode, txtcContact,txtcPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);
        //txtcId = findViewById(R.id.textViewId);
        txtcName = findViewById(R.id.textViewName);
        txtcEmail = findViewById(R.id.textViewEmail);
        txtcAddress = findViewById(R.id.textViewAddress);
        txtcCity = findViewById(R.id.textViewCity);
        txtcState = findViewById(R.id.textViewState);
        txtcPincode = findViewById(R.id.textViewPincode);
        txtcContact = findViewById(R.id.textViewContact);
        txtcPassword = findViewById(R.id.textViewPassword);


       /* UserObject userObject = (UserObject)getIntent().getExtras().getSerializable("userDetails");
        int id = userObject.getId();
        String userobName = userObject.getUserName();
        String userobEmail = userObject.getUserEmail();
        String userobAddress= userObject.getUserAddress();
        String userobCity = userObject.getUserCity();
        String userobState = userObject.getUserState();
        String userobPincode = userObject.getUserPincode();
        String userobContact = userObject.getUserContact();
        String userobPassword = userObject.getUserPassword();

        //txtcId.setText(id);
        txtcName.setText(userobName);
        txtcEmail.setText(userobEmail);
        txtcAddress.setText(userobAddress);
        txtcCity.setText(userobCity);
        txtcState.setText(userobState);
        txtcPincode.setText(userobPincode);
        txtcContact.setText(userobContact);
        txtcPassword.setText(userobPassword);*/
    }
}

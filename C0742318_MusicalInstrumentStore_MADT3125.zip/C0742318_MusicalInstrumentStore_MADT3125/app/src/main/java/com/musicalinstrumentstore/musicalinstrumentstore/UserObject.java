package com.musicalinstrumentstore.musicalinstrumentstore;

import java.io.Serializable;

public class UserObject implements Serializable {




    private int id;
   // private String userobId;
    private String userobName;
    private String userobEmail;
    private String userobAddress;
    private String userobCity;
    private String userobState;
    private String userobPincode;
    private String userobContact;
    private String userobPassword;

    public UserObject()
    {

    }

    public UserObject(String userobName, String userobEmail, String userobAddress, String userobCity, String userobState, String userobPincode, String userobContact, String userobPassword) {
       // this.id = id;
        //this.userobId = userobId;
        this.userobName = userobName;
        this.userobEmail = userobEmail;
        this.userobAddress = userobAddress;
        this.userobCity = userobCity;
        this.userobState = userobState;
        this.userobPincode = userobPincode;
        this.userobContact = userobContact;;
        this.userobPassword = userobPassword;
    }

    public int getId() { return id; }
    public void setId(int id) {
        this.id = id;
    }


    public String getUserName() { return userobName; }
    public void setUserName(String customerName) {
        this.userobName = userobName;
    }


    public String getUserEmail() { return userobEmail; }
    public void setUserEmail(String userobEmail) {
        this.userobEmail = userobEmail;
    }


    public String getUserAddress() { return userobAddress; }
    public void setUserAddress(String userobAddress) {
        this.userobAddress = userobAddress;
    }

    public String getUserCity() { return userobCity; }
    public void setUserCity(String userobCity) {
        this.userobCity = userobCity;
    }


    public String getUserState() { return userobState; }
    public void setUserState(String userobState) {
        this.userobState = userobState;
    }


    public String getUserPincode() { return userobPincode; }
    public void setUserPincode(String userobPincode) {
        this.userobPincode = userobPincode;
    }

    public String getUserContact() { return userobContact; }
    public void setUserContact(String userobContact) {
        this.userobContact = userobContact;
    }



    public String getUserPassword() { return userobPassword; }
    public void setUserPassword(String userobPassword) {
        this.userobPassword = userobPassword;
    }



}

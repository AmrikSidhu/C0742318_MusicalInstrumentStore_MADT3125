package com.musicalinstrumentstore.musicalinstrumentstore;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static android.accounts.AccountManager.KEY_PASSWORD;

public class SqliteHelperUserData extends SQLiteOpenHelper {

    //DATABASE NAME
    public static final String DATABASE_NAME = "mstore.db";

    //DATABASE VERSION
    public static final int DATABASE_VERSION = 1;

    //TABLE NAME
    public static final String TABLE_USERDATA = "user";

    //TABLE USERS COLUMNS
    //ID COLUMN @primaryKey
    public static final String KEY_AUTO = "id";
    public static final String KEY_NAME = "loginname";
    public static final String KEY_EMAIL = "loginemail";
    public static final String KEY_ADDRESS = "loginaddress";
    public static final String KEY_CITY= "logincity";
    public static final String KEY_STATE = "loginstate";
    public static final String KEY_PINCODE = "loginpincode";
    public static final String KEY_CONTACT = "logincontact";
    public static final String KEY_PASSWORD = "loginpassword";
    public static final String KEY_TYPE = "logintype";
    public SqliteHelperUserData(Context context) {
        super(context, "mstore.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase datab) {
        datab.execSQL("create table user (id integer primary key autoincrement ,loginname text,loginemail text,loginaddress text,logincity text,loginstate text,loginpincode text,logincontact text,loginpassword text,logintype text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists userdata");

    }
    public  boolean insert (String loginname , String loginemail , String loginaddress , String logincity , String loginstate , String loginpincode , String logincontact , String loginpassword , String logintype)
    {
        SQLiteDatabase datab = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("loginname",loginname);
        contentValues.put("loginemail",loginemail);
        contentValues.put("loginaddress",loginaddress);
        contentValues.put("logincity",logincity);
        contentValues.put("loginstate",loginstate);
        contentValues.put("loginpincode",loginpincode);
        contentValues.put("logincontact",logincontact);
        contentValues.put("loginpassword",loginpassword);
        contentValues.put("logintype",logintype);
        long insert = datab.insert("user", null,contentValues);
        if (insert == -1)

        {
            return  false;
        }
        else
        {
            return true;
        }

    }
    public  Boolean chkemail(String email)
    {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("select * from user where loginemail=?",new String[]{email});
        if (cursor.getCount()>0)
        {
            return false;
        }
        else
        {
            return  true;
        }
    }

    public User Authenticate(User user) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERDATA, new String[]{KEY_AUTO, KEY_EMAIL, KEY_PASSWORD,KEY_TYPE},//Selecting columns want to query
                KEY_EMAIL + "=?",
                new String[]{user.email},//Where clause
                null, null, null);

        if (cursor != null && cursor.moveToFirst()&& cursor.getCount()>0) {
            //if cursor has value then in user database there is user associated with this given email
            User user1 = new User(cursor.getString(0), cursor.getString(1), cursor.getString(2),cursor.getString(3));

            //Match both passwords check they are same or not
            if (user.password.equalsIgnoreCase(user1.password) && user.logintype.equals(user1.logintype)) {
                return user1;
            }

        }

        //if user password does not matches or there is no record with that email then return @false
        return null;



    }
    public User Authenticate2(User user) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERDATA, new String[]{KEY_AUTO, KEY_EMAIL, KEY_PASSWORD,KEY_TYPE},//Selecting columns want to query
                KEY_EMAIL + "=?",
                new String[]{user.email},//Where clause
                null, null, null);

        if (cursor != null && cursor.moveToFirst()&& cursor.getCount()>0) {
            //if cursor has value then in user database there is user associated with this given email
            User user1 = new User(cursor.getString(0), cursor.getString(1), cursor.getString(2),cursor.getString(3));

            //Match both passwords check they are same or not

            if (user.password.equalsIgnoreCase(user1.password) && user.logintype.equals(user1.logintype)) {
                return user1;
            }
        }

        //if user password does not matches or there is no record with that email then return @false
        return null;



    }
    public Cursor viewData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select * from " + TABLE_USERDATA;
        Cursor cursor =  db.rawQuery(query,null);
        return cursor;
    }


    public Cursor viewDataInPrompt()

    {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "select * from " + TABLE_USERDATA;
        Cursor cursor =  db.rawQuery("select * from " + TABLE_USERDATA , null);
        return cursor;
    }
    public  Integer deleteBYid(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return   db.delete(TABLE_USERDATA,"id = ?",new  String[]{id});

    }



}

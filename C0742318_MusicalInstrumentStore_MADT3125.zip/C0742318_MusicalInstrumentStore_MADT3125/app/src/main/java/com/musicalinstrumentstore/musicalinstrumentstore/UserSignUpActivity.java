package com.musicalinstrumentstore.musicalinstrumentstore;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserSignUpActivity extends AppCompatActivity {
    SqliteHelperUserData userdb;
    private Button btnSignUp;
    private Button btnCancel;
    private EditText edtName,edtEmail,edtAddress,edtCity,edtState,edtPincode,edtContact,edtNPassword,edtCpassword;
    private Button cancel;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_sign_up);
        userdb = new  SqliteHelperUserData(this);
        edtName = (EditText)findViewById(R.id.editTextuserSignupName);
        edtEmail = (EditText)findViewById(R.id.editTextuserSignupEmail);
        edtAddress = (EditText)findViewById(R.id.editTextuserSignupAddress);
        edtCity = (EditText)findViewById(R.id.editTextuserSignupCity);
        edtState = (EditText)findViewById(R.id.editTextuserSignupState);
        edtPincode = (EditText)findViewById(R.id.editTextuserSignupPincode);
        edtContact = (EditText)findViewById(R.id.editTextuserSignupContact);
        edtNPassword = (EditText)findViewById(R.id.editTextuserSignupNpassword);
        edtCpassword = (EditText)findViewById(R.id.editTextuserSignupCpassword);


        btnSignUp = (Button) findViewById(R.id.buttonSignUpReg);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uname = edtName.getText().toString();
                String uemail = edtEmail.getText().toString();
                String uaddress = edtAddress.getText().toString();
                String ucity = edtCity.getText().toString();
                String ustate = edtState.getText().toString();
                String upincode = edtPincode.getText().toString();
                String ucontact = edtContact.getText().toString();
                String unpassword = edtNPassword.getText().toString();
                String ucpassword = edtCpassword.getText().toString();
                String utype = "user";

                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(uemail).matches()) {
                    Toast.makeText(getApplicationContext(), "enter valid email", Toast.LENGTH_SHORT).show();}
                    //Toast.makeText(getApplicationContext(), "enter valid email", Toast.LENGTH_SHORT).show();

                   else if (uname.equals("") || uemail.equals("") || uaddress.equals("") || ucity.equals("") || ustate.equals("") || upincode.equals("") || unpassword.equals("") || ucpassword.equals(""))
                    {
                        Toast.makeText(getApplicationContext(), "All Fields are Reqired", Toast.LENGTH_SHORT).show();
                    }
                   else if (!unpassword.equals(ucpassword))
                    {
                        Toast.makeText(getApplicationContext(),"Password Doesn't match",Toast.LENGTH_SHORT).show();

                    }
                    else
                {
                    if(unpassword.equals(ucpassword))
                    {
                        Boolean chkemail = userdb.chkemail(uemail);
                        if (chkemail==true)
                        {
                            Boolean insert = userdb.insert(uname,uemail,uaddress,ucity,ustate,upincode,ucontact,unpassword,utype);
                            if (insert==true)
                            {
                                Toast.makeText(getApplicationContext(),"Regiteration Success",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"User already exists with this email address",Toast.LENGTH_SHORT).show();
                        }
                    }

                }




            }
        });

        btnCancel = (Button)findViewById(R.id.buttonSignUpCancel);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RegIntent();
            }
        });
    }

    public  void RegIntent()
    {
        Intent intent = new Intent(this,Main2Activity.class);
        startActivity(intent);
    }
}

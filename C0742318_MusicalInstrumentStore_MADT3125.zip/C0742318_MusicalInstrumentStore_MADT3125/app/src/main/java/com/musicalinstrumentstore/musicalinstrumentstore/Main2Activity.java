package com.musicalinstrumentstore.musicalinstrumentstore;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    public static final String PREFS_NAME = "LoginPrefs";
    SqliteHelperUserData sqliteHelper;
    private Button userSignUp;
    private EditText edtEmail;
    private  EditText edtPassword;
    private Switch aSwitch;
    private Button btnlLogin;

    final Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        if (settings.getString("logged", "").toString().equals("logged")) {
            Intent intent = new Intent(Main2Activity.this, MainActivity.class);
            startActivity(intent);}


        sqliteHelper = new SqliteHelperUserData(this);

        SharedPreferences myPrefs=getSharedPreferences("rememberDetails",MODE_PRIVATE);
        final SharedPreferences.Editor editor=myPrefs.edit();
        edtEmail = (EditText)findViewById(R.id.editTextLoginEmail);
        edtPassword = (EditText)findViewById(R.id.editTextLoginPassword) ;
        aSwitch = (Switch)findViewById(R.id.switchLoginRemember);
        edtEmail.setText(myPrefs.getString("email",null));
        edtPassword.setText(myPrefs.getString("password",null));
        btnlLogin = (Button)findViewById(R.id.buttonUserLogin);
        btnlLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = edtEmail.getText().toString();
                String password = edtPassword.getText().toString();
                String logintype = "user";
                String logintype2= "admin";
                if (validate()) {


                    //Authenticate user
                    User currentUser = sqliteHelper.Authenticate(new User(null, email, password,logintype));

                    //Check Authentication is successful or not
                    if (currentUser != null) {
                        if (aSwitch.isChecked()){
                            editor.putString("email",email);
                            editor.putString("password",password);
                            editor.apply();
                        }
                        else{
                            editor.remove("email");
                            editor.remove("password");
                            editor.apply();
                        }

                        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString("logged", "logged");
                        editor.commit();
                        editor.putString("logged", "logged");
                        editor.commit();

                        Toast.makeText(getApplicationContext(),"login Success",Toast.LENGTH_SHORT).show();
                        loginSuccess();


                        //User Logged in Successfully Launch You home screen activity
                       /* Intent intent=new Intent(LoginActivity.this,HomeScreenActivity.class);
                        startActivity(intent);
                        finish();*/
                    }

                   else {
                        Toast.makeText(getApplicationContext(),"warning invoked",Toast.LENGTH_SHORT).show();
                    }
                }



                if (validate2()) {


                    //Authenticate user
                    User currentUser2 = sqliteHelper.Authenticate2(new User(null, email, password,logintype2));

                    //Check Authentication is successful or not
                    if (currentUser2 != null) {
                        if (aSwitch.isChecked()){
                            editor.putString("email",email);
                            editor.putString("password",password);
                            editor.apply();
                        }
                        else{
                            editor.remove("email");
                            editor.remove("password");
                            editor.apply();
                        }

                        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString("logged", "logged");
                        editor.commit();
                        editor.putString("logged", "logged");
                        editor.commit();

                        Toast.makeText(getApplicationContext(),"login Success",Toast.LENGTH_SHORT).show();
                        loginSuccess2();


                        //User Logged in Successfully Launch You home screen activity
                       /* Intent intent=new Intent(LoginActivity.this,HomeScreenActivity.class);
                        startActivity(intent);
                        finish();*/
                    }






                   else {Toast.makeText(getApplicationContext(),"warning invoked",Toast.LENGTH_SHORT).show();
                    }
                }
            }






        });


        userSignUp = (Button)findViewById(R.id.buttonUserSingUp);

         userSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RegIntent();
            }
        });
    }




    public  void RegIntent()
    {
        Intent intent = new Intent(this,UserSignUpActivity.class);
        startActivity(intent);
    }

    public boolean validate() {
        boolean valid = false;

        //Get values from EditText fields
        String Email = edtEmail.getText().toString();
        String Password = edtPassword.getText().toString();
        String Logintype = "user";

        //Handling validation for Email field
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            valid = false;
            Toast.makeText(getApplicationContext(),"enter valid email",Toast.LENGTH_SHORT).show();
        }

        else {
            valid = true;
            Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT).show();
        }

        //Handling validation for Password field
        if (Email.isEmpty() || Password.isEmpty()) {
            valid = false;
            Toast.makeText(getApplicationContext(),"user name and password can not be Empty!",Toast.LENGTH_SHORT).show();
        }

        return valid;
    }

    public boolean validate2() {
        boolean valid = false;

        //Get values from EditText fields
        String Email = edtEmail.getText().toString();
        String Password = edtPassword.getText().toString();
        String Logintype = "admin";

        //Handling validation for Email field
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            valid = false;
            Toast.makeText(getApplicationContext(),"enter valid email",Toast.LENGTH_SHORT).show();
        }

        else {
            valid = true;
            Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT).show();
        }

        //Handling validation for Password field
        if (Email.isEmpty() || Password.isEmpty()) {
            valid = false;
            Toast.makeText(getApplicationContext(),"user name and password can not be Empty!",Toast.LENGTH_SHORT).show();
        }

        return valid;
    }
    public  void loginSuccess()
    {
        String value = edtEmail.getText().toString();
        Intent intent = new Intent(Main2Activity.this,MainActivity.class);
        intent.putExtra("username",value);

        startActivity(intent);
    }
    public  void loginSuccess2()
    {
        String value = edtEmail.getText().toString();
        Intent intent = new Intent(Main2Activity.this,AdminActivity.class);
        intent.putExtra("username",value);

        startActivity(intent);
    }


}

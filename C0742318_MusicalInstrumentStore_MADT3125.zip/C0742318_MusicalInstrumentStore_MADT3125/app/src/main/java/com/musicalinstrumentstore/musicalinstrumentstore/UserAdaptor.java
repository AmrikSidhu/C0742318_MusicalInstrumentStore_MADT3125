package com.musicalinstrumentstore.musicalinstrumentstore;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class UserAdaptor extends ArrayAdapter<UserObject> {

    private List<UserObject> userArrayList;
    private Context mContext;

    public UserAdaptor(Context context, List<UserObject> userList)
    {
        super(context, 0, userList);
        this.userArrayList = userList;
        this.mContext = context;

    }

    @Override
    public int getCount()
    {
        return userArrayList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {

        userViewHolder mHolder;

        if(convertView == null)
        {
            convertView = LayoutInflater.from(mContext)
                    .inflate(R.layout.activity_user_detail,
                            parent,
                            false);
            mHolder = new userViewHolder(convertView);
            convertView.setTag(mHolder);
        }
        else
        {
            mHolder = (userViewHolder)convertView.getTag();
        }

        UserObject currentUser = userArrayList.get(position);


        mHolder.txtUserName.setText(currentUser.getUserName());
        mHolder.txtUseremail.setText(currentUser.getUserEmail());
        mHolder.txtUserAddress.setText(currentUser.getUserAddress());
        mHolder.txtUserCity.setText(currentUser.getUserCity());
        mHolder.txtUserState.setText(currentUser.getUserState());
        mHolder.txtUserPincode.setText(currentUser.getUserPincode());
        mHolder.txtUserContact.setText(currentUser.getUserContact());
        mHolder.txtUserPassword.setText(currentUser.getUserPassword());

        return convertView;


    }


    private class userViewHolder
    {
        //ImageView image;
        TextView txtUserName;
        TextView txtUseremail;
        TextView txtUserAddress;
        TextView txtUserCity;
        TextView txtUserState;
        TextView txtUserPincode;
        TextView txtUserContact;
        TextView txtUserPassword;

        public userViewHolder(View view)
        {
            // image = (ImageView)view.findViewById(R.id.imageView_poster);
            txtUserName = (TextView) view.findViewById(R.id.textViewName);
            txtUseremail = (TextView) view.findViewById(R.id.textViewEmail);
            txtUserAddress = (TextView) view.findViewById(R.id.textViewAddress);
            txtUserCity = (TextView) view.findViewById(R.id.textViewCity);
            txtUserState = (TextView) view.findViewById(R.id.textViewState);
            txtUserPincode = (TextView) view.findViewById(R.id.textViewPincode);
            txtUserContact = (TextView) view.findViewById(R.id.textViewContact);
            txtUserPassword = (TextView) view.findViewById(R.id.textViewPassword);

        }
    }

    //Method for upDate ListView, after filtering list based on SearchBar (EditTextView)
    // =>> Receives filteredList from ListBillActivity call
    public void filterList(ArrayList<UserObject> filteredList)
    {
        userArrayList = filteredList;
        notifyDataSetChanged();
    }

}

package com.musicalinstrumentstore.musicalinstrumentstore;

public class User {
    public String id;
    public String email;
    public String password;
    public String logintype;

    public User(String id, String email, String password, String logintype) {
        this.id = id;
        this.email = email;
        this.password = password;
        this.logintype = logintype;
    }

}
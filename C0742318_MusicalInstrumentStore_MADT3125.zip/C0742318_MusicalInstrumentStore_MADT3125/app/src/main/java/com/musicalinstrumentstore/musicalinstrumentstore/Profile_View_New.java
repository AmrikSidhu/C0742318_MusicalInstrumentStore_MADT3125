package com.musicalinstrumentstore.musicalinstrumentstore;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Profile_View_New extends AppCompatActivity {
    private static final String PREFS_NAME = "LoginPrefs";

    SqliteHelperUserData mydata;

    Button btnViewProfile;
    Button btnDel;
    EditText edttxtid;
    Button adminLogout;
    EditText edtProductTitle;
    EditText edtProductPRice;
    Button btnaddProduct;
    //EditText edtProducType;
    private String []instrumentList = {"Electrical", "Wooden", "Classic", "Western"};
    private Spinner spinnerInstrument;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile__view__new);

        mydata = new SqliteHelperUserData(this);
        spinnerInstrument = findViewById(R.id.spinnerPrpductType);

        btnViewProfile = (Button)findViewById(R.id.btnViewProfile2);
        btnDel = (Button)findViewById(R.id.button_DeleteByID);
        edttxtid = (EditText)findViewById(R.id.editText_Id);
        adminLogout = (Button)findViewById(R.id.buttonAdminLogout) ;
        edtProductTitle  = (EditText)findViewById(R.id.editTextProductName);
        edtProductPRice = (EditText)findViewById(R.id.editTextProductPrice);
        spinnerInstrument = (Spinner) findViewById(R.id.spinnerPrpductType);
        btnaddProduct = (Button)findViewById(R.id.buttonAddProduct);


        ViewAll();
        deleteData();


        ArrayAdapter<String>mStringArrayAdapter = new ArrayAdapter<>(Profile_View_New.this,
                android.R.layout.simple_spinner_dropdown_item, instrumentList);

        spinnerInstrument.setAdapter(mStringArrayAdapter);

        spinnerInstrument.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
            {
                String selectedItem = adapterView.getItemAtPosition(i).toString();
                Toast.makeText(Profile_View_New.this, instrumentList[i], Toast.LENGTH_SHORT).show();

            }




            @Override
            public void onNothingSelected(AdapterView<?> adapterView)
            {
                Toast.makeText(Profile_View_New.this, "onNothingSelected", Toast.LENGTH_SHORT).show();
            }
        });



        adminLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.remove("logged");
                editor.commit();
                finish();

            }
        });

    }

    public void ViewAll()
    {
        btnViewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Cursor cursor =  mydata.viewDataInPrompt();
               if(cursor.getCount() == 0)
               {
                   showMessage("error","nothing found");
                   return;

               }
               StringBuffer buffer = new StringBuffer();
               while (cursor.moveToNext())
               {
                   buffer.append("ID: " + cursor.getString(0) + "\n");
                   buffer.append("NAME: " + cursor.getString(1) + "\n");
                   buffer.append("EMAIL: " + cursor.getString(2) + "\n");
                   buffer.append("ADDRESS: " + cursor.getString(3) + "\n");
                   buffer.append("CITY: " + cursor.getString(4) + "\n");
                   buffer.append("STATE: " + cursor.getString(5) + "\n");
                   buffer.append("PINCODE: " + cursor.getString(6) + "\n");
                   buffer.append("CONTACT: " + cursor.getString(7) + "\n");
                   buffer.append("PASSWORD: " + cursor.getString(8) + "\n");
                   buffer.append("UserType: " + cursor.getString(9) + "\n\n");
               }
                showMessage("DATA",buffer.toString());




            }
        });
    }

    public  void deleteData()
    {
        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deleteRows = mydata.deleteBYid(edttxtid.getText().toString());
                if(deleteRows > 0)
                {
                    showMessage("QueryOK!","one row effected");
                    return;
                }
                else {
                    showMessage("row not found","no one row effected");
                    return;
                }
            }
        });
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();

    }
}

package com.musicalinstrumentstore.musicalinstrumentstore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class HomeInstrumentsWeb extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_instruments_web);
        webView = findViewById(R.id.homeWeb);

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://cosmomusic.ca");

    }
}

package com.musicalinstrumentstore.musicalinstrumentstore;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class UserData extends AppCompatActivity {
    SqliteHelperUserData db;
    ListView userlist;
    ArrayList<UserObject> listitem;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_data);
        db = new  SqliteHelperUserData(this);
        userlist =findViewById(R.id.user_list);
        listitem = new ArrayList<>();
        viewData();
        userlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String text = userlist.getItemAtPosition(position).toString();
                Toast.makeText(UserData.this,"" +text,Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void viewData() {
        Cursor cursor = db.viewData();
        if (cursor.getCount() == 0)
        {
            Toast.makeText(this,"no data to display",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor.moveToNext())
            {
                int id = cursor.getInt(0);
               //String custid = cursor.getString(1);
                String custname = cursor.getString(1);
                String custemail = cursor.getString(2);
                String custaddress = cursor.getString(3);
                String custcity = cursor.getString(4);
                String custstate = cursor.getString(5);
                String custpincode = cursor.getString(6);
                String custcontact = cursor.getString(7);
                String custpassword = cursor.getString(8);
                listitem.add(new UserObject(custname,custemail,custaddress,custcity,custstate,custpincode,custcontact,custpassword));
            }
            adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1);
            userlist.setAdapter(adapter);
        }
    }
}
